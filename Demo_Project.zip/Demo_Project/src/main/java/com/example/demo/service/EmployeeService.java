package com.example.demo.service;

import java.lang.reflect.Field;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ReflectionUtils;

import com.example.demo.entity.EmployeeDto;
import com.example.demo.repository.EmployeeRepository;

@Service
public class EmployeeService {
	
	@Autowired
	EmployeeRepository repository;
	
	public EmployeeDto saveEmployee(EmployeeDto employeeDto) {
		return repository.save(employeeDto);
	}
	
	public List<EmployeeDto> saveEmployees(List<EmployeeDto> employeeDtos) {
		return repository.saveAll(employeeDtos);
	}
	
	public List<EmployeeDto> getEmployees(){
		return repository.findAll();
	}
	
	public Optional<EmployeeDto> getEmployeeById(int id) {
		return repository.findById(id);
	}
	
	public EmployeeDto getEmployeeByName(String name) {
	return repository.findByName(name);
	}
	
	public String deleteEmployeeById(int id) {
		repository.deleteById(id);
		return "employee details deleted"+id;
 	}
	
	public EmployeeDto updateEmployee(EmployeeDto employeeDto) {
		EmployeeDto existingEmployee=repository.findById(employeeDto.getEmpId()).orElse(null);
		existingEmployee.setEmpName(employeeDto.getEmpName());
		existingEmployee.setEmpMoNo(employeeDto.getEmpMoNo());
		existingEmployee.setEmpSalary(employeeDto.getEmpSalary());
		return repository.save(existingEmployee);
	}
	
	public EmployeeDto updateEmployeeByFields(int id,Map<String,Object> fields) {
		Optional<EmployeeDto> existingEmployee=repository.findById(id);
		
		if(existingEmployee.isPresent()) {
			fields.forEach((key, value)->{
				Field field= ReflectionUtils.findField(EmployeeDto.class, key);
				field.setAccessible(true);
				ReflectionUtils.setField(field, existingEmployee.get(), value);
			});
			return repository.save(existingEmployee.get());
		}
		return null;
	}
	
	
	
	

}
