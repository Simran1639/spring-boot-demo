package com.example.demo.controller;

import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.EmployeeDto;
import com.example.demo.service.EmployeeService;


@RestController
public class EmployeeController {

	@Autowired
    EmployeeService service;
	
	@PostMapping("/saveEmployee")
	public EmployeeDto addEmployee(@RequestBody EmployeeDto employeeDto) {
		return service.saveEmployee(employeeDto);
	}
	
	@PostMapping("/addEmployees")
	public List<EmployeeDto> addEmployees(@RequestBody List<EmployeeDto> employeeDtos){
		return service.saveEmployees(employeeDtos);
	}
	
	@GetMapping("/employees")
	public List<EmployeeDto> findAllEmployees(){
		return service.getEmployees();
	}
	
	@GetMapping("/employee/{id}")
	public Optional<EmployeeDto> findEmployeeById(@PathVariable("id") int id) {
		return service.getEmployeeById(id);
	}
	
	@GetMapping("/employeeName/{name}")
	public EmployeeDto findEmployeeByName(@PathVariable String name) {
		return service.getEmployeeByName(name);
	}
	
	@PutMapping("/update")
	public EmployeeDto updateEmployee(@RequestBody EmployeeDto employeeDto) {
		return service.updateEmployee(employeeDto);
	}
	
	@DeleteMapping("/delete/{id}")
	public String deleteEmployee(@PathVariable int id) {
		return service.deleteEmployeeById(id);
	}
	@PatchMapping("/patch/{id}")
	public EmployeeDto updateEmployeeFields(@PathVariable int id,@RequestBody Map<String,Object> fields) {
		return service.updateEmployeeByFields(id,fields);
	}
}